<?php
function woocommerce_pedido_abierto_añadir_producto_ajax() {
    check_ajax_referer('add_product_to_order_nonce', 'security');

    $order_id = absint($_POST['order_id']);
    $product_id = absint($_POST['product_id']);

    $order = wc_get_order($order_id);
    $product = wc_get_product($product_id);

    if (!$order || !$product) {
        wp_send_json_error(array('message' => 'Pedido o producto no encontrado.'));
        return;
    }

    if ($order->get_status() !== 'abierto') {
        wp_send_json_error(array('message' => 'El pedido no está en estado "abierto".'));
        return;
    }

    // Añadir el producto al pedido
    $item_id = $order->add_product($product, 1); // Añadir 1 unidad del producto
    $order->calculate_totals();
    $order->save();

    wp_send_json_success(array('message' => 'Producto añadido correctamente.'));
}
add_action('wp_ajax_add_product_to_order', 'woocommerce_pedido_abierto_añadir_producto_ajax');
add_action('wp_ajax_nopriv_add_product_to_order', 'woocommerce_pedido_abierto_añadir_producto_ajax');
