<?php
// Agregar la funcionalidad para manejar los botones de edición de pedidos abiertos

// Mostrar botón "Editar" si el pedido está en estado "abierto"
add_action('woocommerce_my_account_my_orders_actions', 'agregar_boton_editar_si_abierto', 10, 2);

function agregar_boton_editar_si_abierto($actions, $order) {
    // Verificar si el pedido está en estado 'abierto'
    if ('abierto' === $order->get_status()) {
        $actions['editar_pedido'] = array(
            'url'  => wc_get_endpoint_url('edit-order', $order->get_id(), wc_get_page_permalink('myaccount')),
            'name' => __('Editar', 'woocommerce'),
        );
    }
    return $actions;
}

// Puedes añadir otras funcionalidades adicionales relacionadas con el estado del pedido aquí
