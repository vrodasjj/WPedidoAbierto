<?php
function woocommerce_pedido_abierto_buscar_producto_ajax() {
    check_ajax_referer('search_product_nonce', 'security');

    $search_term = sanitize_text_field($_POST['search']);
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 5,
        's' => $search_term
    );
    $products = new WP_Query($args);

    if ($products->have_posts()) {
        ob_start();
        while ($products->have_posts()) {
            $products->the_post();
            echo '<div class="product-result">';
            echo '<span>' . get_the_title() . '</span>';
            echo '<button class="add-to-order" data-product_id="' . get_the_ID() . '">' . __('Añadir al pedido', 'woocommerce') . '</button>';
            echo '</div>';
        }
        wp_reset_postdata();
        wp_send_json_success(ob_get_clean());
    } else {
        wp_send_json_error(array('message' => 'No se encontraron productos.'));
    }
}
add_action('wp_ajax_product_search', 'woocommerce_pedido_abierto_buscar_producto_ajax');
add_action('wp_ajax_nopriv_product_search', 'woocommerce_pedido_abierto_buscar_producto_ajax');
