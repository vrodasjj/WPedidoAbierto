jQuery(document).ready(function($) {

    // Búsqueda de productos en tiempo real
    $('#add_product_search').on('input', function() {
        let searchQuery = $(this).val();

        if (searchQuery.length >= 3) {
            $.ajax({
                url: wc_pedido_abierto_params.ajax_url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'wc_pedido_abierto_search_products',
                    security: wc_pedido_abierto_params.search_products_nonce,
                    term: searchQuery
                },
                success: function(response) {
                    if (response.success) {
                        $('#product-search-results').html(response.data.html);
                    } else {
                        $('#product-search-results').html('<p>' + response.data.message + '</p>');
                    }
                },
                error: function(xhr, status, error) {
                    $('#product-search-results').html('<p>Error en la búsqueda AJAX.</p>');
                    console.error('Error en la búsqueda AJAX: ', error);
                }
            });
        } else {
            $('#product-search-results').empty();
        }
    });

    // Manejar la adición de productos al pedido
    $(document).on('click', '.add-product', function() {
        let productId = $(this).data('product-id');
        let orderId = $('form.woocommerce-form-edit-order').find('input[name="order_id"]').val();

        $.ajax({
            url: wc_pedido_abierto_params.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'wc_pedido_abierto_add_product',
                security: wc_pedido_abierto_params.search_products_nonce,
                product_id: productId,
                order_id: orderId,
                quantity: 1
            },
            success: function(response) {
                if (response.success) {
                    $('#product-search-results').html('<p>' + response.message + '</p>');
                    setTimeout(function() {
                        location.reload(); // Recargar la página para reflejar los cambios en el pedido
                    }, 1000);
                } else {
                    alert(response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error al agregar el producto: ', error);
            }
        });
    });
});
