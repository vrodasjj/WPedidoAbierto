<?php
/**
 * Plugin Name: WooCommerce Pedido Abierto
 * Description: Permite a los clientes editar pedidos en estado "abierto" y gestiona el saldo a favor.
 * Version: 2.0.4
 * Author: Tu Nombre
 * Text Domain: woocommerce-pedido-abierto
 * Domain Path: /languages
 */

// Asegurar que WooCommerce esté activo
add_action('plugins_loaded', 'wc_pedido_abierto_check_dependencies');
function wc_pedido_abierto_check_dependencies() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', 'wc_pedido_abierto_missing_woocommerce_notice');
        return;
    }
}

function wc_pedido_abierto_missing_woocommerce_notice() {
    echo '<div class="error"><p>' . __('WooCommerce Pedido Abierto requiere WooCommerce para funcionar. Por favor, activa WooCommerce.', 'woocommerce-pedido-abierto') . '</p></div>';
}

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente
}

// Registrar el estado "abierto"
if (!function_exists('wc_register_order_status_abierto')) {
    add_action('init', 'wc_register_order_status_abierto');
    function wc_register_order_status_abierto() {
        register_post_status('wc-abierto', array(
            'label'                     => _x('Abierto', 'Order status', 'woocommerce-pedido-abierto'),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop('Abierto <span class="count">(%s)</span>', 'Abierto <span class="count">(%s)</span>', 'woocommerce-pedido-abierto'),
        ));
    }
}

// Agregar el estado "abierto" a WooCommerce
if (!function_exists('wc_add_order_status_abierto')) {
    add_filter('wc_order_statuses', 'wc_add_order_status_abierto');
    function wc_add_order_status_abierto($order_statuses) {
        $new_order_statuses = array();
        foreach ($order_statuses as $key => $status) {
            $new_order_statuses[$key] = $status;
            if ('wc-processing' === $key) {
                $new_order_statuses['wc-abierto'] = _x('Abierto', 'Order status', 'woocommerce-pedido-abierto');
            }
        }
        return $new_order_statuses;
    }
}

// Mostrar un botón para editar pedidos en estado "abierto"
if (!function_exists('wc_add_edit_order_button')) {
    add_filter('woocommerce_my_account_my_orders_actions', 'wc_add_edit_order_button', 10, 2);
    function wc_add_edit_order_button($actions, $order) {
        if ($order->get_status() === 'abierto') {
            $actions['edit'] = array(
                'url'  => wp_nonce_url(add_query_arg('order_id', $order->get_id(), get_permalink(get_option('woocommerce_edit_order_page_id'))), 'woocommerce_edit_order'),
                'name' => __('Editar Pedido', 'woocommerce-pedido-abierto'),
            );
        }
        return $actions;
    }
}

// Manejar la edición del pedido
if (!function_exists('wc_handle_order_editing')) {
    add_action('template_redirect', 'wc_handle_order_editing');
    function wc_handle_order_editing() {
        if (isset($_GET['order_id']) && is_page(get_option('woocommerce_edit_order_page_id'))) {
            $order_id = absint($_GET['order_id']);
            $order = wc_get_order($order_id);

            if ($order && $order->get_status() === 'abierto' && current_user_can('edit_shop_orders')) {
                wc_get_template('view-order-custom.php', array('order' => $order), '', plugin_dir_path(__FILE__) . 'templates/');
                exit;
            } else {
                wc_add_notice(__('No tienes permiso para editar este pedido.', 'woocommerce-pedido-abierto'), 'error');
                wp_redirect(wc_get_account_endpoint_url('orders'));
                exit;
            }
        }
    }
}

// Encolar el archivo JavaScript en la página de edición del pedido
if (!function_exists('wc_enqueue_pedido_abierto_scripts')) {
    add_action('wp_enqueue_scripts', 'wc_enqueue_pedido_abierto_scripts');
    function wc_enqueue_pedido_abierto_scripts() {
        if (is_page(get_option('woocommerce_edit_order_page_id'))) {
            wp_enqueue_script('wc-pedido-abierto-script', plugins_url('assets/js/script.js', __FILE__), array('jquery'), null, true);

            wp_localize_script('wc-pedido-abierto-script', 'wc_pedido_abierto_params', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'search_products_nonce' => wp_create_nonce('search_products_nonce')
            ));
        }
    }
}

// Definir el manejador AJAX para la búsqueda de productos
if (!function_exists('wc_pedido_abierto_search_products')) {
    add_action('wp_ajax_wc_pedido_abierto_search_products', 'wc_pedido_abierto_search_products');
    add_action('wp_ajax_nopriv_wc_pedido_abierto_search_products', 'wc_pedido_abierto_search_products');
    function wc_pedido_abierto_search_products() {
        check_ajax_referer('search_products_nonce', 'security');

        $term = isset($_POST['term']) ? sanitize_text_field($_POST['term']) : '';
        if (empty($term)) {
            wp_send_json_error(array('message' => __('No se encontró ningún término de búsqueda.', 'woocommerce-pedido-abierto')));
        }

        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 10,
            's' => $term,
            'post_status' => 'publish'
        );
        $products = get_posts($args);

        if (empty($products)) {
            wp_send_json_error(array('message' => __('No se encontraron productos.', 'woocommerce-pedido-abierto')));
        }

        ob_start();
        foreach ($products as $product) {
            $product_obj = wc_get_product($product->ID);

            echo '<div class="product-result">';
            echo '  <div class="product-info">';
            echo '    <span class="product-result-name">' . esc_html($product_obj->get_name()) . '</span>';
            echo '    <span class="product-result-price">' . wc_price($product_obj->get_price()) . '</span>';
            echo '  </div>';
            echo '  <button class="add-product" data-product-id="' . esc_attr($product->ID) . '">' . __('Añadir', 'woocommerce-pedido-abierto') . '</button>';
            echo '</div>';
        }
        $html = ob_get_clean();

        wp_send_json_success(array('html' => $html));
    }
}

// Encolar el archivo CSS en la página de edición del pedido
if (!function_exists('wc_enqueue_pedido_abierto_styles')) {
    add_action('wp_enqueue_scripts', 'wc_enqueue_pedido_abierto_styles');
    function wc_enqueue_pedido_abierto_styles() {
        if (is_page(get_option('woocommerce_edit_order_page_id'))) {
            wp_enqueue_style('wc-pedido-abierto-style', plugins_url('assets/css/style.css', __FILE__), array(), null);
        }
    }
}

// Manejador AJAX para agregar productos al pedido
if (!function_exists('wc_pedido_abierto_add_product')) {
    add_action('wp_ajax_wc_pedido_abierto_add_product', 'wc_pedido_abierto_add_product');
    function wc_pedido_abierto_add_product() {
        check_ajax_referer('search_products_nonce', 'security');

        $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
        $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
        $quantity = isset($_POST['quantity']) ? absint($_POST['quantity']) : 1;

        if (!$order_id || !$product_id) {
            wp_send_json_error(array('message' => __('Datos insuficientes para agregar el producto.', 'woocommerce-pedido-abierto')));
        }

        $order = wc_get_order($order_id);
        if (!$order || $order->get_status() !== 'abierto') {
            wp_send_json_error(array('message' => __('No se puede editar este pedido.', 'woocommerce-pedido-abierto')));
        }

        try {
            $order->add_product(wc_get_product($product_id), $quantity);
            $order->calculate_totals();
            $order->save();
        } catch (Exception $e) {
            wp_send_json_error(array('message' => __('Error al agregar el producto: ', 'woocommerce-pedido-abierto') . $e->getMessage()));
        }

        wp_send_json_success(array('message' => __('Producto agregado correctamente.', 'woocommerce-pedido-abierto')));
    }
}
