<?php

class WC_Order_Status_Manager {

    // Propiedad para almacenar pedidos
    private $orders;

    public function __construct() {
        $this->orders = array();
    }

    // Funci�n para agregar un nuevo estado a un pedido
    public function add_order_status($order_id, $status) {
        // Obtenemos el pedido
        $order = wc_get_order($order_id);

        if (!$order) {
            return false; // Si el pedido no existe, retornamos false
        }

        // Verificamos si el estado no est� ya agregado
        if (!in_array($status, wc_get_order_statuses())) {
            // Agregamos el estado personalizado
            register_post_status('wc-' . $status, array(
                'label'                     => ucfirst($status),
                'public'                    => true,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop(ucfirst($status) . ' (%s)', ucfirst($status) . ' (%s)')
            ));
        }

        // Actualizamos el estado del pedido
        $order->update_status($status);
        return true;
    }

    // Funci�n para obtener el estado actual de un pedido
    public function get_order_status($order_id) {
        // Obtenemos el pedido
        $order = wc_get_order($order_id);

        if (!$order) {
            return false;
        }

        // Retornamos el estado del pedido
        return $order->get_status();
    }

    // Funci�n para verificar si un pedido tiene un estado espec�fico
    public function is_order_status($order_id, $status) {
        $current_status = $this->get_order_status($order_id);
        return ($current_status === $status);
    }

    // Funci�n para obtener todos los pedidos con un estado espec�fico
    public function get_orders_by_status($status) {
        $args = array(
            'status' => 'wc-' . $status,
            'limit' => -1,
        );

        // Obtenemos todos los pedidos con el estado especificado
        $orders = wc_get_orders($args);
        return $orders;
    }
}

?>
