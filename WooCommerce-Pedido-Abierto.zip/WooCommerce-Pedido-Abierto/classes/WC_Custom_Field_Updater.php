<?php

class WC_Custom_Field_Updater {

    // Inicializamos los campos personalizados
    private $custom_fields;

    public function __construct() {
        $this->custom_fields = array();
    }

    // Funci�n para actualizar un campo personalizado en un pedido
    public function update_custom_field($order_id, $field_name, $value) {
        // Obtenemos el pedido
        $order = wc_get_order($order_id);

        if (!$order) {
            return false; // Si el pedido no existe, retornamos false
        }

        // Actualizamos o a�adimos el campo personalizado al pedido
        update_post_meta($order_id, $field_name, $value);

        return true;
    }

    // Funci�n para obtener el valor de un campo personalizado
    public function get_custom_field($order_id, $field_name) {
        // Obtenemos el valor del campo personalizado
        return get_post_meta($order_id, $field_name, true);
    }

    // Elimina un campo personalizado
    public function delete_custom_field($order_id, $field_name) {
        // Elimina el campo personalizado del pedido
        delete_post_meta($order_id, $field_name);
    }
}

?>
