<?php

class WC_Pedido_Abierto {
    private $pedido_abierto;

    public function __construct() {
        $this->pedido_abierto = new Pedido_Abierto();
    }

    public function add_pedido($pedido) {
        return $this->pedido_abierto->add_pedido($pedido);
    }
}

class Pedido_Abierto {
    private $pedidos;

    public function __construct() {
        $this->pedidos = array();
    }

    public function add_pedido($pedido) {
        // Lógica para agregar un nuevo pedido
        // Por ejemplo:
        if (!in_array($pedido, $this->pedidos)) {
            $this->pedidos[] = $pedido;
            return true;
        }
        return false;
    }

    public function get_pedidos() {
        return $this->pedidos;
    }
}
