<?php
defined('ABSPATH') || exit;

$current_user_id = get_current_user_id();
$current_balance = get_user_meta($current_user_id, 'accumulated_balance', true) ?: 0;

global $wpdb;
$balance_history = $wpdb->get_results(
    $wpdb->prepare("SELECT * FROM {$wpdb->prefix}pedido_abierto_saldos WHERE user_id = %d ORDER BY date DESC", $current_user_id)
);
$coupons = wc_get_coupons(['user_id' => $current_user_id]);
?>

<h2><?php _e('Historial de Uso de Saldo y Cupones', 'woocommerce'); ?></h2>

<h3><?php _e('Historial de Saldo', 'woocommerce'); ?></h3>
<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
    <thead>
        <tr>
            <th><?php _e('Fecha', 'woocommerce'); ?></th>
            <th><?php _e('Acción', 'woocommerce'); ?></th>
            <th><?php _e('Monto', 'woocommerce'); ?></th>
            <th><?php _e('Producto/Cantidad', 'woocommerce'); ?></th>
            <th><?php _e('Pedido Asociado', 'woocommerce'); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($balance_history as $record) : ?>
            <tr>
                <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($record->date)); ?></td>
                <td><?php echo ucfirst($record->action); ?></td>
                <td><?php echo wc_price($record->amount); ?></td>
                <td><?php echo $record->product_id . ' x ' . $record->quantity; ?></td>
                <td><?php echo $record->order_id ? '<a href="' . esc_url(wc_get_endpoint_url('view-order', $record->order_id, wc_get_page_permalink('myaccount'))) . '">' . __('Pedido #', 'woocommerce') . $record->order_id . '</a>' : 'N/A'; ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<h3><?php _e('Historial de Cupones Generados', 'woocommerce'); ?></h3>
<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
    <thead>
        <tr>
            <th><?php _e('Código de Cupón', 'woocommerce'); ?></th>
            <th><?php _e('Monto', 'woocommerce'); ?></th>
            <th><?php _e('Estado', 'woocommerce'); ?></th>
            <th><?php _e('Fecha de Creación', 'woocommerce'); ?></th>
            <th><?php _e('Fecha de Uso', 'woocommerce'); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($coupons as $coupon) : 
            $coupon_obj = new WC_Coupon($coupon->get_id());
            $used = $coupon_obj->get_usage_count() > 0;
            $usage_date = $used ? get_post_meta($coupon->get_id(), 'date_used', true) : '-';
        ?>
            <tr>
                <td><?php echo esc_html($coupon_obj->get_code()); ?></td>
                <td><?php echo wc_price($coupon_obj->get_amount()); ?></td>
                <td><?php echo $used ? __('Usado', 'woocommerce') : __('No Usado', 'woocommerce'); ?></td>
                <td><?php echo date_i18n(get_option('date_format'), strtotime($coupon_obj->get_date_created())); ?></td>
                <td><?php echo $usage_date ? date_i18n(get_option('date_format'), strtotime($usage_date)) : '-'; ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
