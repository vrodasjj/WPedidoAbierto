<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Incluir la cabecera del tema de WooCommerce
get_header( 'shop' );
?>

<div class="woocommerce">
    <h2><?php esc_html_e( 'Mis Pedidos', 'woocommerce' ); ?></h2>

    <?php
    do_action( 'woocommerce_before_account_orders', $has_orders );

    if ( $has_orders ) : ?>
        <table class="shop_table shop_table_responsive my_account_orders">
            <thead>
                <tr>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-number"><span class="nobr"><?php esc_html_e( 'Pedido', 'woocommerce' ); ?></span></th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-date"><span class="nobr"><?php esc_html_e( 'Fecha', 'woocommerce' ); ?></span></th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status"><span class="nobr"><?php esc_html_e( 'Estado', 'woocommerce' ); ?></span></th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-total"><span class="nobr"><?php esc_html_e( 'Total', 'woocommerce' ); ?></span></th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-actions"><span class="nobr"><?php esc_html_e( 'Acciones', 'woocommerce' ); ?></span></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $customer_orders->orders as $customer_order ) :
                    $order      = wc_get_order( $customer_order );
                    $item_count = $order->get_item_count() - $order->get_item_count_refunded();
                    ?>
                    <tr class="order">
                        <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number" data-title="<?php esc_attr_e( 'Pedido', 'woocommerce' ); ?>">
                            <a href="<?php echo esc_url( $order->get_view_order_url() ); ?>">
                                <?php echo esc_html( $order->get_order_number() ); ?>
                            </a>
                        </td>
                        <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-date" data-title="<?php esc_attr_e( 'Fecha', 'woocommerce' ); ?>">
                            <time datetime="<?php echo esc_attr( $order->get_date_created()->date( 'c' ) ); ?>">
                                <?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?>
                            </time>
                        </td>
                        <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-status" data-title="<?php esc_attr_e( 'Estado', 'woocommerce' ); ?>">
                            <?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?>
                        </td>
                        <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-total" data-title="<?php esc_attr_e( 'Total', 'woocommerce' ); ?>">
                            <?php
                            /* translators: 1: formatted order total 2: total order items */
                            printf( _n( '%1$s por %2$s artículo', '%1$s por %2$s artículos', $item_count, 'woocommerce' ), wp_kses_post( $order->get_formatted_order_total() ), esc_html( $item_count ) );
                            ?>
                        </td>
                        <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-actions" data-title="<?php esc_attr_e( 'Acciones', 'woocommerce' ); ?>">
                            <?php
                            $actions = wc_get_account_orders_actions( $order );

                            if ( $order->get_status() === 'abierto' ) {
                                $actions['edit'] = array(
                                    'url'  => wp_nonce_url( add_query_arg( 'order_id', $order->get_id(), get_permalink( get_option( 'woocommerce_edit_order_page_id' ) ) ), 'woocommerce_edit_order' ),
                                    'name' => __( 'Editar Pedido', 'woocommerce' ),
                                );
                            }

                            if ( ! empty( $actions ) ) {
                                foreach ( $actions as $key => $action ) {
                                    echo '<a href="' . esc_url( $action['url'] ) . '" class="woocommerce-button button ' . sanitize_html_class( $key ) . '">' . esc_html( $action['name'] ) . '</a>';
                                }
                            }
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php do_action( 'woocommerce_after_account_orders', $has_orders ); ?>
    <?php else : ?>
        <p class="woocommerce-notice woocommerce-notice--info woocommerce-info"><?php esc_html_e( 'No has realizado ningún pedido.', 'woocommerce' ); ?></p>
    <?php endif; ?>
</div>

<?php
// Incluir el pie de página del tema de WooCommerce
get_footer( 'shop' );
?>
