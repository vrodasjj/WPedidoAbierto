<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Incluir la cabecera del tema de WooCommerce
get_header( 'shop' );
?>

<div class="woocommerce">
    <?php
    global $wp;
    $order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
    $order = wc_get_order( $order_id );

    if ( ! $order ) {
        echo '<p class="woocommerce-error">' . esc_html__( 'Pedido no válido.', 'woocommerce' ) . '</p>';
        return;
    }

    wc_print_notices();

    echo '<h2>' . sprintf( esc_html__( 'Editar Pedido #%s', 'woocommerce' ), $order->get_order_number() ) . '</h2>';

    $items = $order->get_items();
    ?>
    <form method="post" action="" class="woocommerce-form woocommerce-form-edit-order">
        <h3><?php esc_html_e( 'Productos del Pedido', 'woocommerce' ); ?></h3>
        <table class="shop_table shop_table_responsive my_account_orders">
            <thead>
                <tr>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-product-name"><?php esc_html_e( 'Producto', 'woocommerce' ); ?></th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-product-quantity"><?php esc_html_e( 'Cantidad', 'woocommerce' ); ?></th>
                    <th class="woocommerce-orders-table__header woocommerce-orders-table__header-remove-item"><?php esc_html_e( 'Eliminar', 'woocommerce' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $items as $item_id => $item ) : ?>
                    <tr>
                        <td class="woocommerce-orders-table__cell product-name">
                            <?php echo esc_html( $item->get_name() ); ?>
                        </td>
                        <td class="woocommerce-orders-table__cell product-quantity">
                            <input type="number" name="item_qty[<?php echo esc_attr( $item_id ); ?>]" value="<?php echo esc_attr( $item->get_quantity() ); ?>" min="1">
                        </td>
                        <td class="woocommerce-orders-table__cell product-remove">
                            <button type="button" class="remove-item-button" data-item-id="<?php echo esc_attr( $item_id ); ?>">&times;</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div id="product-search-container">
            <h3><?php esc_html_e( 'Añadir Producto al Pedido', 'woocommerce' ); ?></h3>
            <input type="text" id="add_product_search" placeholder="<?php esc_attr_e( 'Buscar producto...', 'woocommerce' ); ?>">
            <div id="product-search-results"></div>
        </div>
        <button type="submit" class="button woocommerce-button-edit-order-update"> <?php esc_html_e( 'Actualizar Pedido', 'woocommerce' ); ?> </button>
    </form>
</div>

<?php
// Incluir el pie de página del tema de WooCommerce
get_footer( 'shop' );
?>
