<?php
/**
 * Plantilla personalizada para "Mi cuenta"
 * Esta plantilla sobrescribe la plantilla predeterminada de WooCommerce
 */

defined( 'ABSPATH' ) || exit;

// Mostrar un mensaje de depuración
echo '<p>Este es un mensaje de depuración desde la plantilla personalizada de Mi cuenta.</p>';

// Mostrar el contenido original de "Mi cuenta"
do_action( 'woocommerce_account_navigation' ); ?>

<div class="woocommerce-MyAccount-content">
    <?php
        // Acción original que muestra el contenido de la cuenta
        do_action( 'woocommerce_account_content' );
    ?>
</div>

<?php
// Agregar botón "Editar" para pedidos en estado "abierto"
add_action('woocommerce_my_account_my_orders_actions', 'agregar_boton_editar_si_abierto', 10, 2);

function agregar_boton_editar_si_abierto($actions, $order) {
    if ($order->get_status() === 'wc-abierto') {
        $actions['editar_pedido'] = array(
            'url'  => wc_get_endpoint_url('edit-order', $order->get_id(), wc_get_page_permalink('myaccount')),
            'name' => __('Editar', 'woocommerce'),
        );
    }
    return $actions;
}
?>
