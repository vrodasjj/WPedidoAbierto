<?php
defined('ABSPATH') || exit;

$order_id = get_query_var('order_id');
$current_user_id = get_current_user_id();
$current_balance = get_user_meta($current_user_id, 'accumulated_balance', true) ?: 0;

global $wpdb;
$order_balance = $wpdb->get_results($wpdb->prepare("SELECT SUM(amount) AS total_balance FROM {$wpdb->prefix}pedido_abierto_saldos WHERE user_id = %d AND order_id = %d", $current_user_id, $order_id));
$current_edit_balance = $order_balance ? $order_balance[0]->total_balance : 0;
?>

<div class="order-balance-section">
    <h3><?php _e('Saldo Disponible', 'woocommerce'); ?></h3>
    <p><?php _e('Saldo acumulado en ediciones anteriores:', 'woocommerce'); ?> <?php echo wc_price($current_balance); ?></p>
    <p><?php _e('Saldo generado en esta edición:', 'woocommerce'); ?> <?php echo wc_price($current_edit_balance); ?></p>
    <p><strong><?php _e('Saldo total disponible:', 'woocommerce'); ?> <?php echo wc_price($current_balance + $current_edit_balance); ?></strong></p>

    <label for="apply-balance-switch" class="apply-balance-label">
        <input type="checkbox" id="apply-balance-switch" name="apply_balance" value="1" checked>
        <?php _e('Usar saldo disponible para esta edición', 'woocommerce'); ?>
    </label>
</div>

<form id="edit-order-form" method="post">
    <h3><?php _e('Editar Pedido', 'woocommerce'); ?></h3>
    <p><?php _e('Agregue o elimine productos según lo desee. Los cambios serán recalculados.', 'woocommerce'); ?></p>
    <!-- Aquí irían los campos de edición del pedido según los productos -->

    <button type="submit" class="button alt"><?php _e('Guardar Cambios', 'woocommerce'); ?></button>
</form>

<script>
jQuery(document).ready(function($) {
    $('#apply-balance-switch').on('change', function() {
        if ($(this).is(':checked')) {
            console.log('Aplicando saldo acumulado a este pedido.');
        } else {
            console.log('El saldo acumulado no se aplicará.');
        }
    });

    $('#edit-order-form').on('submit', function(e) {
        e.preventDefault();
        // Aquí se manejaría la lógica para enviar la edición del pedido mediante AJAX
        alert('<?php _e('El pedido ha sido actualizado correctamente.', 'woocommerce'); ?>');
    });
});
</script>
