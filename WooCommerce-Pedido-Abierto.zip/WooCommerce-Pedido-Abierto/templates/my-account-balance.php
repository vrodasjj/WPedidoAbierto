<?php
defined('ABSPATH') || exit;

$current_user_id = get_current_user_id();
$current_balance = get_user_meta($current_user_id, 'accumulated_balance', true) ?: 0;

global $wpdb;
$balance_history = $wpdb->get_results(
    $wpdb->prepare("SELECT * FROM {$wpdb->prefix}pedido_abierto_saldos WHERE user_id = %d ORDER BY date DESC", $current_user_id)
);
?>

<h2><?php _e('Gestión de Saldo', 'woocommerce'); ?></h2>

<p><strong><?php _e('Saldo acumulado disponible:', 'woocommerce'); ?> <?php echo wc_price($current_balance); ?></strong></p>

<h3><?php _e('Historial de Saldo', 'woocommerce'); ?></h3>
<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
    <thead>
        <tr>
            <th><?php _e('Fecha', 'woocommerce'); ?></th>
            <th><?php _e('Acción', 'woocommerce'); ?></th>
            <th><?php _e('Monto', 'woocommerce'); ?></th>
            <th><?php _e('Producto/Cantidad', 'woocommerce'); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($balance_history as $record) : ?>
            <tr>
                <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($record->date)); ?></td>
                <td><?php echo ucfirst($record->action); ?></td>
                <td><?php echo wc_price($record->amount); ?></td>
                <td><?php echo $record->product_id . ' x ' . $record->quantity; ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<h3><?php _e('Generar Cupón de Descuento', 'woocommerce'); ?></h3>
<form id="generate-coupon-form" method="post" class="woocommerce-form">
    <p><?php _e('Seleccione el monto del cupón:', 'woocommerce'); ?></p>
    <input type="number" name="coupon_amount" min="1" max="<?php echo esc_attr($current_balance); ?>" step="0.01" required>
    <button type="submit" class="button alt"><?php _e('Generar Cupón', 'woocommerce'); ?></button>
</form>
<div id="coupon-success-message" style="display:none; color: green; font-weight: bold;"><?php _e('¡Cupón generado con éxito!', 'woocommerce'); ?></div>

<script>
jQuery(document).ready(function($) {
    $('#generate-coupon-form').on('submit', function(e) {
        e.preventDefault();
        var couponAmount = $('input[name="coupon_amount"]').val();
        if (couponAmount > 0) {
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                method: 'POST',
                data: {
                    action: 'generate_coupon_from_balance',
                    amount: couponAmount,
                    nonce: '<?php echo wp_create_nonce('pedido_abierto_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        $('#coupon-success-message').show().delay(3000).fadeOut();
                        $('input[name="coupon_amount"]').val('');
                    } else {
                        alert(response.data.message || '<?php _e('Error al generar el cupón.', 'woocommerce'); ?>');
                    }
                }
            });
        }
    });
});
</script>
