<?php
// Funci�n para manejar la actualizaci�n de los pedidos
function woocommerce_pedido_abierto_actualizar_pedido($order_id) {
    $order = wc_get_order($order_id);

    if (!$order) {
        return false;
    }

    // Verificar si el pedido est� en estado "abierto"
    if ($order->get_status() !== 'abierto') {
        return false;
    }

    // Procesar las cantidades de productos enviadas
    if (isset($_POST['quantity']) && is_array($_POST['quantity'])) {
        foreach ($_POST['quantity'] as $item_id => $new_quantity) {
            $item = $order->get_item($item_id);
            if ($item && $new_quantity > 0) {
                $item->set_quantity($new_quantity);
                $item->save();
            }
        }
    }

    // Recalcular totales del pedido
    $order->calculate_totals();
    $order->save();
    return true;
}

// Funci�n para manejar la adici�n de nuevos productos al pedido
function woocommerce_pedido_abierto_a�adir_producto($order_id, $product_id) {
    $order = wc_get_order($order_id);
    $product = wc_get_product($product_id);

    if (!$order || !$product) {
        return false;
    }

    // Verificar si el pedido est� en estado "abierto"
    if ($order->get_status() !== 'abierto') {
        return false;
    }

    // Agregar el producto al pedido
    $order->add_product($product, 1);
    $order->calculate_totals();
    $order->save();
    return true;
}
