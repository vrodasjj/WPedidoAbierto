<?php

defined('ABSPATH') || exit;

// Función que crea la tabla de saldos a favor cuando se activa el plugin
function woocommerce_pedido_abierto_create_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'pedido_abierto_saldos';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        order_id bigint(20) UNSIGNED NOT NULL,
        amount decimal(10,2) NOT NULL,
        date datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'woocommerce_pedido_abierto_create_table');

// Encola los scripts necesarios para la búsqueda de productos y la actualización de pedidos vía AJAX
function woocommerce_pedido_abierto_enqueue_scripts() {
    wp_enqueue_script('pedido-abierto-ajax', plugins_url('/js/pedido-abierto.js', __FILE__), array('jquery'), null, true);
    wp_localize_script('pedido-abierto-ajax', 'pedidoAbiertoAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('pedido_abierto_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'woocommerce_pedido_abierto_enqueue_scripts');

// Maneja la búsqueda de productos vía AJAX
function woocommerce_pedido_abierto_search_products() {
    check_ajax_referer('pedido_abierto_nonce', 'nonce');

    $search_query = isset($_POST['query']) ? sanitize_text_field($_POST['query']) : '';
    
    if (empty($search_query)) {
        wp_send_json_error('Empty search query');
    }

    $args = array(
        'post_type' => 'product',
        's' => $search_query,
        'posts_per_page' => 10,
    );
    $query = new WP_Query($args);

    $products = array();
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $products[] = array(
                'id' => get_the_ID(),
                'name' => get_the_title(),
                'price' => get_post_meta(get_the_ID(), '_price', true),
            );
        }
    }

    wp_reset_postdata();
    wp_send_json_success($products);
}
add_action('wp_ajax_pedido_abierto_search_products', 'woocommerce_pedido_abierto_search_products');
add_action('wp_ajax_nopriv_pedido_abierto_search_products', 'woocommerce_pedido_abierto_search_products');

// Maneja la adición de productos al pedido a través de la API REST
function woocommerce_pedido_abierto_add_product_to_order() {
    check_ajax_referer('pedido_abierto_nonce', 'nonce');

    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

    if ($order_id && $product_id && $quantity > 0) {
        $order = wc_get_order($order_id);
        if ($order) {
            $order->add_product(wc_get_product($product_id), $quantity);
            $order->calculate_totals();
            wp_send_json_success('Product added to order');
        } else {
            wp_send_json_error('Order not found');
        }
    } else {
        wp_send_json_error('Invalid parameters');
    }
}
add_action('wp_ajax_pedido_abierto_add_product_to_order', 'woocommerce_pedido_abierto_add_product_to_order');
add_action('wp_ajax_nopriv_pedido_abierto_add_product_to_order', 'woocommerce_pedido_abierto_add_product_to_order');

// Añade un menú en el backend para gestionar los saldos a favor
function woocommerce_pedido_abierto_admin_menu() {
    add_menu_page(
        __('Gestión de Saldos', 'woocommerce'),  // Título de la página
        __('Saldos a Favor', 'woocommerce'),     // Título del menú
        'manage_woocommerce',                   // Capacidad requerida
        'gestion-saldos',                       // Slug de la página
        'woocommerce_pedido_abierto_manage_saldos',  // Función que muestra la página
        'dashicons-money-alt',                  // Icono del menú
        56                                      // Posición del menú
    );
}
add_action('admin_menu', 'woocommerce_pedido_abierto_admin_menu');

// Función que muestra la página de gestión de saldos en el backend
function woocommerce_pedido_abierto_manage_saldos() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'pedido_abierto_saldos';

    // Obtiene todos los registros de saldo a favor
    $results = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    echo '<div class="wrap"><h1>' . __('Gestión de Saldos a Favor', 'woocommerce') . '</h1>';
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>' . __('ID Cliente', 'woocommerce') . '</th><th>' . __('Pedido ID', 'woocommerce') . '</th><th>' . __('Monto', 'woocommerce') . '</th><th>' . __('Fecha', 'woocommerce') . '</th></tr></thead>';
    echo '<tbody>';

    // Muestra los saldos en la tabla
    foreach ($results as $row) {
        echo '<tr>';
        echo '<td>' . esc_html($row['user_id']) . '</td>';
        echo '<td>' . esc_html($row['order_id']) . '</td>';
        echo '<td>' . wc_price($row['amount']) . '</td>';
        echo '<td>' . esc_html($row['date']) . '</td>';
        echo '</tr>';
    }

    echo '</tbody></table>';
    echo '</div>';
}

// Función para permitir la edición del saldo a favor desde el backend
function woocommerce_pedido_abierto_edit_saldo($user_id, $new_amount) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'pedido_abierto_saldos';

    // Actualiza el saldo a favor para el usuario
    $wpdb->update(
        $table_name,
        array('amount' => $new_amount),   // Nueva cantidad de saldo
        array('user_id' => $user_id),     // Donde el user_id coincida
        array('%f'),                      // Formato para el nuevo saldo
        array('%d')                       // Formato para el user_id
    );
}

// Formulario para editar el saldo en el backend
function woocommerce_pedido_abierto_edit_saldo_form($user_id) {
    $current_balance = woocommerce_get_customer_credit_balance($user_id);
    echo '<form method="post" action="">';
    echo '<h2>' . __('Editar Saldo a Favor', 'woocommerce') . '</h2>';
    echo '<p>' . sprintf(__('Saldo actual para el cliente #%s: %s', 'woocommerce'), $user_id, wc_price($current_balance)) . '</p>';
    echo '<p><label for="new_saldo">' . __('Nuevo Saldo:', 'woocommerce') . '</label>';
    echo '<input type="number" name="new_saldo" value="' . esc_attr($current_balance) . '" step="0.01"></p>';
    echo '<p><input type="submit" name="update_saldo" value="' . __('Actualizar Saldo', 'woocommerce') . '" class="button-primary"></p>';
    echo '</form>';

    // Procesa la actualización cuando el formulario se envía
    if (isset($_POST['update_saldo'])) {
        $new_amount = floatval($_POST['new_saldo']);
        woocommerce_pedido_abierto_edit_saldo($user_id, $new_amount);
        echo '<p>' . __('Saldo actualizado con éxito.', 'woocommerce') . '</p>';
    }
}

// Función para mostrar la opción de editar saldo en el backend
function woocommerce_pedido_abierto_admin_edit_saldo_option() {
    if (isset($_GET['user_id'])) {
        $user_id = intval($_GET['user_id']);
        woocommerce_pedido_abierto_edit_saldo_form($user_id);
    }
}
add_action('admin_menu', 'woocommerce_pedido_abierto_admin_edit_saldo_option');

?>
