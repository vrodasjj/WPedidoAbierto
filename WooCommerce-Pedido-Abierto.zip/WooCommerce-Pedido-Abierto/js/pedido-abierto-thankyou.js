jQuery(document).ready(function($) {
    // Capturar el evento click en el botón "Abrir Pedido"
    $('#abrir-pedido').on('click', function(e) {
        e.preventDefault();

        // Obtener el ID del pedido desde el atributo data del botón
        var orderId = $(this).data('order-id');
        
        // Validar que el ID del pedido esté presente
        if (!orderId) {
            alert('ID de pedido no encontrado.');
            return;
        }

        // Deshabilitar el botón y mostrar mensaje de carga
        $(this).prop('disabled', true).text('Abriendo pedido...');

        $.ajax({
            url: pedidoAbiertoAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'abrir_pedido',
                order_id: orderId,
                nonce: pedidoAbiertoAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Mostrar mensaje de éxito y actualizar el estado en la interfaz
                    $('#abrir-pedido').text('Pedido abierto con éxito').prop('disabled', true);
                    $('#estado-pedido').text('Abierto');
                } else {
                    // Restaurar botón y mostrar mensaje de error
                    $('#abrir-pedido').prop('disabled', false).text('Abrir Pedido');
                    alert(response.data.message || 'Error al abrir el pedido.');
                }
            },
            error: function() {
                // Restaurar botón en caso de error
                $('#abrir-pedido').prop('disabled', false).text('Abrir Pedido');
                alert('Hubo un error al intentar abrir el pedido.');
            }
        });
    });
});
