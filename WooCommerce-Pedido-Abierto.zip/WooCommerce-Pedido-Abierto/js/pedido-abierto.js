jQuery(document).ready(function($) {
    // Búsqueda dinámica de productos
    $('#search-product').on('input', function() {
        var query = $(this).val();
        if (query.length > 2) {
            $.ajax({
                url: ajaxurl, // URL para AJAX en WordPress
                method: 'POST',
                data: {
                    action: 'search_products',
                    query: query,
                    security: ajax_nonce // Seguridad usando nonce
                },
                success: function(response) {
                    if (response.success) {
                        $('#product-results').html(response.data);
                    } else {
                        alert('Error: ' + response.data);
                    }
                },
                error: function() {
                    alert('Hubo un error en la búsqueda de productos.');
                }
            });
        }
    });

    // Agregar producto al pedido
    $(document).on('click', '.add-product-btn', function() {
        var product_id = $(this).data('product-id');
        var order_id = $('#order_id').val();
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'add_product_to_order',
                product_id: product_id,
                order_id: order_id,
                security: ajax_nonce // Seguridad usando nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload(); // Recargar la página para ver el cambio
                } else {
                    alert('Error: ' + response.data.message);
                }
            },
            error: function() {
                alert('Hubo un error al añadir el producto.');
            }
        });
    });
});
