jQuery(document).ready(function($) {
    var totalOriginal = 0; // Asumimos que obtienes el total original del pedido en algún lugar
    var totalNuevo = 0; 

    // Función para recalcular el saldo
    function recalcularSaldo() {
        var saldoFavor = totalOriginal - totalNuevo;
        if (saldoFavor < 0) saldoFavor = 0;
        $('#saldo-favor').text(saldoFavor.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));
    }

    // Al cambiar las cantidades
    $('.quantity-input').on('input', function() {
        var quantity = $(this).val();
        var price = $(this).data('price');
        var subtotal = quantity * price;

        // Actualizar el subtotal en la fila
        $(this).closest('tr').find('.product-subtotal').text(subtotal.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));

        // Recalcular el total del pedido
        totalNuevo = 0;
        $('.quantity-input').each(function() {
            var qty = $(this).val();
            var prc = $(this).data('price');
            totalNuevo += qty * prc;
        });
        $('#total-pedido').text(totalNuevo.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));

        // Calcular el saldo a favor en tiempo real
        recalcularSaldo();
    });

    // Buscar productos cuando el usuario escribe en el campo de búsqueda
    $('#product-search').on('input', function() {
        var searchTerm = $(this).val();

        if (searchTerm.length < 3) return; // Evitar búsquedas con menos de 3 caracteres

        $.ajax({
            url: ajax_object.ajaxurl,
            method: 'POST',
            data: {
                action: 'search_products',
                security: ajax_object.pedido_abierto_nonce, // Nonce actualizado
                term: searchTerm
            },
            success: function(response) {
                if (response.success) {
                    $('#product-results').empty(); // Limpiar resultados anteriores
                    $.each(response.data, function(index, product) {
                        $('#product-results').append('<li data-id="' + product.id + '">' + product.name + ' (' + product.sku + ') - ' + product.price + '</li>');
                    });
                }
            }
        });
    });
});
