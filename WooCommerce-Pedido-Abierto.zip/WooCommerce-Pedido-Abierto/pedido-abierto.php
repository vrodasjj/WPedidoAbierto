<?php
/**
 * Plugin Name: WooCommerce Pedido Abierto
 * Description: Un plugin para gestionar pedidos abiertos y saldo a favor en WooCommerce.
 * Version: 1.0
 * Author: Tu Nombre
 */

function registrar_estado_abierto() {
    register_post_status('wc-abierto', array(
        'label'                     => _x('Abierto', 'Order status', 'woocommerce'),
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop('Abierto (%s)', 'Abierto (%s)', 'woocommerce')
    ));
}
add_action('init', 'registrar_estado_abierto');

function a�adir_estado_abierto($order_statuses) {
    $nuevo_estado = array();

    foreach ($order_statuses as $key => $status) {
        $nuevo_estado[$key] = $status;
        if ('wc-pending' === $key) {
            $nuevo_estado['wc-abierto'] = _x('Abierto', 'Order status', 'woocommerce');
        }
    }

    return $nuevo_estado;
}
add_filter('wc_order_statuses', 'a�adir_estado_abierto');


// Definir el acceso directo a WP
defined('ABSPATH') || exit;

// Crear la tabla para el saldo a favor
function create_balance_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'pedido_abierto_saldos';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL,
        order_id mediumint(9) NOT NULL,
        product_id mediumint(9) NOT NULL,
        action varchar(50) NOT NULL,
        amount decimal(10, 2) NOT NULL,
        quantity mediumint(9) NOT NULL,
        date datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'create_balance_table');

// Notificaci�n autom�tica a administrador
add_action('woocommerce_order_status_changed', 'notify_admin_open_order', 10, 4);
function notify_admin_open_order($order_id, $old_status, $new_status, $order) {
    if ($new_status === 'wc-open') {
        $admin_email = get_option('admin_email');
        $subject = 'Pedido Abierto - ' . $order_id;
        $message = 'El pedido #' . $order_id . ' ha sido marcado como abierto.';
        wp_mail($admin_email, $subject, $message);
    }
}

// Env�o de email al cliente tras la edici�n de un pedido
add_action('woocommerce_order_status_changed', 'send_order_edit_summary_to_customer', 10, 4);
function send_order_edit_summary_to_customer($order_id, $old_status, $new_status, $order) {
    if ($new_status === 'wc-open') {
        $user_id = $order->get_user_id();
        $user = get_userdata($user_id);
        $customer_email = $user->user_email;

        global $wpdb;
        $balance_history = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM pedido_abierto_saldos WHERE user_id = %d AND order_id = %d ORDER BY date DESC", $user_id, $order_id)
        );

        $subject = 'Resumen de cambios en su pedido #' . $order_id;
        $message = 'Estimado ' . $user->first_name . ",\n\n";
        $message .= 'A continuaci�n se muestra un resumen de los cambios realizados en su pedido abierto:\n\n';

        foreach ($balance_history as $record) {
            $action = ucfirst($record->action);
            $product_info = $record->product_id . ' x ' . $record->quantity;
            $message .= $action . ' - ' . $product_info . ' - ' . wc_price($record->amount) . "\n";
        }

        $message .= "\n" . 'Saldo acumulado: ' . wc_price(get_user_meta($user_id, 'accumulated_balance', true) ?: 0);
        $message .= "\n\nGracias por su compra. Para m�s detalles, puede visitar su cuenta en nuestra tienda.\n\nSaludos,\nEl equipo de Soporte";
        wp_mail($customer_email, $subject, $message);
    }
}
// Generar un cup�n a partir del saldo
add_action('wp_ajax_generate_coupon_from_balance', 'generate_coupon_and_notify');
function generate_coupon_and_notify() {
    check_ajax_referer('pedido_abierto_nonce', 'nonce');

    $user_id = get_current_user_id();
    $amount = floatval($_POST['amount']);

    // Obtener el saldo actual
    $current_balance = get_user_meta($user_id, 'accumulated_balance', true) ?: 0;

    // Asegurarse de que el monto no exceda el saldo actual
    if ($amount > $current_balance) {
        wp_send_json_error(['message' => 'Saldo insuficiente para generar el cup�n.']);
    }

    // Generar un c�digo de cup�n aleatorio con un prefijo identificable
    $coupon_code = 'SALDO-' . wp_generate_password(8, false);

    // Crear el cup�n
    $coupon = new WC_Coupon();
    $coupon->set_code($coupon_code);
    $coupon->set_discount_type('fixed_cart');
    $coupon->set_amount($amount);
    $coupon->set_individual_use(false);
    $coupon->set_usage_limit(1);
    $coupon->set_customer_email(wp_get_current_user()->user_email);
    $coupon->set_date_expires(null);

    // Guardar el cup�n y actualizar el saldo del usuario
    $coupon->save();
    update_user_meta($user_id, 'accumulated_balance', $current_balance - $amount);

    // Preparar detalles del email
    $user = get_userdata($user_id);
    $customer_email = $user->user_email;
    $subject = 'Cup�n generado exitosamente - ' . $coupon_code;
    $message = "Hola " . $user->first_name . ",\n\n";
    $message .= "Se ha generado un cup�n de descuento utilizando su saldo acumulado. Aqu� est�n los detalles del cup�n:\n\n";
    $message .= "C�digo del Cup�n: " . $coupon_code . "\n";
    $message .= "Monto: " . wc_price($amount) . "\n";
    $message .= "Condiciones: Cup�n acumulable, de un solo uso, sin caducidad, y exclusivo para su cuenta.\n\n";
    $message .= "Saldo acumulado restante: " . wc_price($current_balance - $amount) . "\n\n";
    $message .= "Gracias por confiar en nosotros.\n\nSaludos,\nEl equipo de Soporte";

    // Enviar la notificaci�n por email
    wp_mail($customer_email, $subject, $message);

    // Respuesta de �xito
    wp_send_json_success(['message' => 'Cup�n generado y email enviado.', 'coupon_code' => $coupon_code]);
}

// Registrar el endpoint "edit-order" en la p�gina "Mi Cuenta"
function woocommerce_pedido_abierto_registrar_endpoint() {
    add_rewrite_endpoint('edit-order', EP_ROOT | EP_PAGES);
}
add_action('init', 'woocommerce_pedido_abierto_registrar_endpoint');

// Mostrar la p�gina de edici�n de pedido
add_action('woocommerce_account_edit-order_endpoint', 'woocommerce_pedido_abierto_mostrar_pagina_edicion');
function woocommerce_pedido_abierto_mostrar_pagina_edicion() {
    global $wp_query;
    
    $order_id = isset($wp_query->query_vars['edit-order']) ? absint($wp_query->query_vars['edit-order']) : 0;
    if ($order_id) {
        wc_get_template('edit-order.php', array('order_id' => $order_id));
    } else {
        echo '<p>Pedido no encontrado.</p>';
    }
}

// A�adir el nuevo endpoint a la lista de enlaces de "Mi Cuenta"
add_filter('woocommerce_account_menu_items', 'woocommerce_pedido_abierto_agregar_link_mi_cuenta');
function woocommerce_pedido_abierto_agregar_link_mi_cuenta($items) {
    $items['edit-order'] = __('Editar Pedido', 'woocommerce');
    return $items;
}
// Filtros para gestionar el saldo en el backend
add_action('admin_menu', 'add_balance_management_page');
function add_balance_management_page() {
    add_menu_page(
        __('Balance Management', 'woocommerce'),
        __('Balance Management', 'woocommerce'),
        'manage_woocommerce',
        'balance-management',
        'render_balance_management_page',
        'dashicons-admin-users',
        56
    );
}

function render_balance_management_page() {
    global $wpdb;

    $customers = $wpdb->get_results("SELECT DISTINCT user_id FROM {$wpdb->prefix}pedido_abierto_saldos");

    echo '<div class="wrap"><h1>' . __('Customer Balance Management', 'woocommerce') . '</h1>';
    echo '<table class="widefat fixed" cellspacing="0"><thead><tr>';
    echo '<th>' . __('Customer ID', 'woocommerce') . '</th>';
    echo '<th>' . __('Customer Name', 'woocommerce') . '</th>';
    echo '<th>' . __('Email', 'woocommerce') . '</th>';
    echo '<th>' . __('Balance Available', 'woocommerce') . '</th>';
    echo '<th>' . __('Action', 'woocommerce') . '</th>';
    echo '</tr></thead><tbody>';

    foreach ($customers as $customer) {
        $user_info = get_userdata($customer->user_id);
        $current_balance = get_user_meta($customer->user_id, 'accumulated_balance', true) ?: 0;

        echo '<tr>';
        echo '<td>' . esc_html($customer->user_id) . '</td>';
        echo '<td>' . esc_html($user_info->display_name) . '</td>';
        echo '<td>' . esc_html($user_info->user_email) . '</td>';
        echo '<td>' . wc_price($current_balance) . '</td>';
        echo '<td><a href="' . admin_url('admin.php?page=balance-management&user_id=' . $customer->user_id) . '" class="button">' . __('View Details', 'woocommerce') . '</a></td>';
        echo '</tr>';
    }

    echo '</tbody></table></div>';

    if (isset($_GET['user_id'])) {
        $user_id = intval($_GET['user_id']);
        render_customer_balance_details($user_id);
    }
}

function render_customer_balance_details($user_id) {
    global $wpdb;

    echo '<h2>' . __('Balance and Coupons for Customer ID:', 'woocommerce') . ' ' . $user_id . '</h2>';
    echo '<h3>' . __('Balance History', 'woocommerce') . '</h3>';

    $balance_history = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM {$wpdb->prefix}pedido_abierto_saldos WHERE user_id = %d ORDER BY date DESC", $user_id)
    );

    echo '<table class="widefat fixed" cellspacing="0"><thead><tr>';
    echo '<th>' . __('Date', 'woocommerce') . '</th>';
    echo '<th>' . __('Action', 'woocommerce') . '</th>';
    echo '<th>' . __('Amount', 'woocommerce') . '</th>';
    echo '<th>' . __('Product/Quantity', 'woocommerce') . '</th>';
    echo '</tr></thead><tbody>';

    foreach ($balance_history as $record) {
        echo '<tr>';
        echo '<td>' . date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($record->date)) . '</td>';
        echo '<td>' . ucfirst($record->action) . '</td>';
        echo '<td>' . wc_price($record->amount) . '</td>';
        echo '<td>' . $record->product_id . ' x ' . $record->quantity . '</td>';
        echo '</tr>';
    }

    echo '</tbody></table>';
}
